
import Home from "./pages/Home.svelte";
import Comparison from "./pages/ComparisonPage.svelte";


export default {
    '/': Home,
    '/home': Home,
    '/ComparisonPage': Comparison,
}