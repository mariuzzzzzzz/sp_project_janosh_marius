<script>
</script>

<h1>Welcome to the COVIDxEMPLOYEES Interface!</h1>
<div class="image-container">
    <img src="/img/covid.jpg" alt="covid" />
    <img src="/img/employees.png" alt="employees" />
</div>


<style>
    h1 {
        padding-top: 50px;
        padding-bottom: 20px;
        text-align: center;
    }
    .image-container {
    display: flex;
    flex-direction: column;
    align-items: center;
  }

  .image-container img {
        width: 100%;
        max-width: 270px; /* Adjust the maximum width as needed */
        max-height: 5000px; /* Adjust the maximum height as needed */
        object-fit: contain; /* Maintain aspect ratio and fit within the container */
        margin-bottom: 10px; /* Add some spacing between the images */
    }
</style>
